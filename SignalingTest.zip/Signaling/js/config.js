/* eslint-disable no-unused-vars */

// Make a copy of this file and save it as config.js (in the js directory).

// Set this to the base URL of your sample server, such as 'https://your-app-name.herokuapp.com'.
// Do not include the trailing slash. See the README for more information:

var SAMPLE_SERVER_BASE_URL = 'http://YOUR-SERVER-URL';

// OR, if you have not set up a web server that runs the learning-opentok-php code,
// set these values to OpenTok API key, a valid session ID, and a token for the session.
// For test purposes, you can obtain these from https://tokbox.com/account.

var API_KEY = "46820744";
var SESSION_ID = "1_MX40NjgyMDc0NH5-MTU5MzY1OTg4NjcyNX5TMXpvL204N0RYcjVwRHpwQVZuRURSMkl-UH4";
var TOKEN = "T1==cGFydG5lcl9pZD00NjgyMDc0NCZzaWc9MWRjNjliNzQ1OTlmMGQ5MGI5YzA5MWNlNDkwOTJjZjVlYzVkZjYwZTpzZXNzaW9uX2lkPTFfTVg0ME5qZ3lNRGMwTkg1LU1UVTVNelkxT1RnNE5qY3lOWDVUTVhwdkwyMDROMFJZY2pWd1JIcHdRVlp1UlVSU01rbC1VSDQmY3JlYXRlX3RpbWU9MTU5MzY1OTkwOSZub25jZT0wLjQxNjI4OTc3ODc5MTQ3MTkmcm9sZT1wdWJsaXNoZXImZXhwaXJlX3RpbWU9MTU5NDI2NDcwNSZpbml0aWFsX2xheW91dF9jbGFzc19saXN0PQ==";
